# Application notes

## Resume section: Selected portfolio projects

- Customer records: Created a customer-records workflow with required-field checks, duplicate-email prevention, search, status filters, and CSV import/export.
- Excel data cleanup: Standardized 42 fictional customer records, preserved source data, documented corrections, and flagged 10 records for follow-up.
- Inventory reporting: Organized inventory data using a seven-table SQL schema, documented field definitions, and prepared 12 queries for stock and purchasing analysis.

## Short application description

My portfolio includes customer record maintenance, Excel data cleanup, and inventory reporting projects. The samples show how I organize records, check missing or duplicate information, document corrections, and prepare data for handoff.

## Interview preparation

Be ready to demonstrate a record correction, explain why an uncertain value should remain flagged, and walk through one SQL report. Describe any AI assistance honestly if asked. Use only claims you can explain and demonstrate. Do not claim paid client experience, measured business savings, typing speed, or production deployment from these samples.
