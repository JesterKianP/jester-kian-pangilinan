# Data Entry Portfolio

Three practice projects demonstrate customer record maintenance, Excel data cleanup, and inventory reporting. All sample businesses and records are fictional.

## Review in five minutes

1. Read Data Entry Portfolio.pdf for the project overview.
2. Open Projects/02 Excel Data Cleanup/Northstar Customer Data Cleanup.xlsx and review Data Summary, then compare raw and cleaned records.
3. Open Projects/01 Customer Records/index.html in a browser and try adding, filtering, and exporting a sample record.
4. Review Projects/03 Inventory Reporting/docs/erd.png and sql/05_reporting_queries.sql. Database setup is optional for document review.

Each project includes CASE STUDY.md and a README. Project folders contain one selected source copy; duplicate screenshots, temporary outputs, virtual environments, local databases, and Git history are excluded.

## Applying to jobs

Attach the PDF when a work sample is requested. Share this full ZIP when the employer accepts supporting files. The customer demo needs its neighboring CSS and JavaScript files, so extract the ZIP before opening it. A local file path is not a public portfolio link.

Use APPLICATION NOTES.md for project descriptions and resume bullets. Add your name and preferred contact details to the editable overview before personalizing it for an application. These are portfolio projects, not paid employment or client work.
