# Excel customer data cleanup

Open the workbook in Excel and begin with Data Summary. Raw Data preserves the input; Cleaned Data documents changes; Quality Checks records source issues and unresolved follow-up.

The included CSVs are static handoff copies. They do not preserve workbook formulas or formatting. Older screenshots are excluded because they show a previous workbook version.

All records are fictional. See CASE STUDY.md for the workflow and verified record counts.
