# Excel Data Cleanup

An Excel workbook that keeps original customer data alongside cleaned records, source-issue flags, and a concise quality summary.

## Task

Prepare inconsistent customer records for review while keeping uncertain information visible.

## Workflow

Preserve raw data, trim spacing, standardize name case, normalize email and recognizable U.S. phone formats, then log corrections and unresolved issues.

## Verified sample

42 records: 32 marked READY and 10 marked FOLLOW UP. Four rows have duplicate-email flags, two invalid-email flags, and two missing-required-field flags. Issue categories may overlap.

## Review the work

Open the workbook in Projects/02 Excel Data Cleanup. Compare Row ID 1001 across Raw Data, Cleaned Data, and Quality Checks, then read Data Summary.

## Judgment

Missing or uncertain values stay unresolved. Similar company names are not merged without confirmation. Formatting corrections remain documented even when a row is ready.
