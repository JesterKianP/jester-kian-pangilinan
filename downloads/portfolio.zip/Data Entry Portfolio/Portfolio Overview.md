# Data Entry Portfolio

Customer records, Excel data quality, and inventory reporting.

## Customer Records

A browser-based customer workspace for entering, updating, finding, and handing off structured customer records.

**Task**: Keep customer details and order statuses consistent while reducing duplicate entry.

**Workflow**: Enter or import customer records, review validation messages, search and filter the list, correct records, and export a CSV handoff.

**Quality controls**: Required name and email fields, email-format validation, case-insensitive duplicate prevention, and spreadsheet-safe CSV export.

**Review the work**: Open Projects/01 Customer Records/index.html. Add a fictional customer, try the same email twice, filter by status, then export the results.

**Scope**: Browser-local demonstration with fictional sample data. Accounts and payments are simulated. No production usage or typing-speed claim is made.

## Excel Data Cleanup

An Excel workbook that keeps original customer data alongside cleaned records, source-issue flags, and a concise quality summary.

**Task**: Prepare inconsistent customer records for review while keeping uncertain information visible.

**Workflow**: Preserve raw data, trim spacing, standardize name case, normalize email and recognizable U.S. phone formats, then log corrections and unresolved issues.

**Verified sample**: 42 records: 32 marked READY and 10 marked FOLLOW UP. Four rows have duplicate-email flags, two invalid-email flags, and two missing-required-field flags. Issue categories may overlap.

**Review the work**: Open the workbook in Projects/02 Excel Data Cleanup. Compare Row ID 1001 across Raw Data, Cleaned Data, and Quality Checks, then read Data Summary.

**Judgment**: Missing or uncertain values stay unresolved. Similar company names are not merged without confirmation. Formatting corrections remain documented even when a row is ready.

## Inventory Reporting

A PostgreSQL inventory project with a Python and Streamlit interface for product records, stock movements, purchasing, and reporting.

**Task**: Organize inventory information and preserve a traceable stock-movement history.

**Workflow**: Maintain product records, record stock operations, track purchase orders, and review inventory and replenishment reports.

**Technical evidence**: Seven core relational tables, an ERD and data dictionary, 12 reporting queries, and controlled database functions for stock operations.

**Review the work**: Start with docs/erd.png and docs/data_dictionary.md in Projects/03 Inventory Reporting. Read sql/05_reporting_queries.sql. The README contains database and dashboard setup steps.

**Verification scope**: Current local test run: 6 passed and 6 database integration tests skipped because no test database was configured. Native PostgreSQL concurrency and connected dashboard screenshots remain unverified.