# Data dictionary

All identifiers are generated identity integers unless noted. PostgreSQL `numeric` is used for money; quantities are whole-number `integer`s. Parent rows use `RESTRICT` deletion to preserve history, except purchase order items cascade when their order is intentionally removed (normal application behavior will preserve/cancel orders instead).

| Table | Column | Type | Rules / meaning |
|---|---|---|---|
| categories | category_id | integer | PK |
|  | category_name | varchar(100) | required, unique |
|  | description | text | optional |
| suppliers | supplier_id | integer | PK |
|  | supplier_name | varchar(160) | required |
|  | contact_name, contact_email, phone, address | text/varchar | optional contact details; email has basic `@` check |
|  | active | boolean | required, defaults true |
| products | product_id | integer | PK |
|  | sku | varchar(40) | required, unique |
|  | product_name | varchar(180) | required, nonblank |
|  | category_id, supplier_id | integer | required FKs to categories and default supplier; deletes restricted |
|  | unit_cost, unit_price | numeric(12,2) | required, nonnegative |
|  | reorder_level | integer | required, nonnegative, defaults 0 |
|  | active | boolean | required, defaults true; deactivate instead of delete |
|  | created_at, updated_at | timestamptz | required timestamps |
| inventory_balances | product_id | integer | PK and FK to product; one row per product |
|  | quantity_on_hand | integer | required, nonnegative, defaults 0 |
|  | last_updated | timestamptz | required timestamp |
| stock_movements | movement_id | bigint | PK |
|  | product_id | integer | required FK to product; deletion restricted |
|  | movement_type | varchar(12) | receipt, issue or adjustment |
|  | quantity_delta | integer | nonzero; receipts positive, issues negative, adjustments signed |
|  | reference, notes | varchar/text | optional external reference and explanation |
|  | request_key | uuid | unique, optional idempotency key; runtime operations set it |
|  | movement_date | date | business date; defaults current date |
|  | created_at | timestamptz | audit timestamp |
| purchase_orders | order_id | integer | PK |
|  | supplier_id | integer | required FK; supplier deletion restricted |
|  | order_date, expected_date | date | required order date; expected date optional but not before order date |
|  | status | varchar(20) | draft, ordered, partially_received, received or cancelled |
|  | notes | text | optional |
|  | created_at, updated_at | timestamptz | required timestamps |
| purchase_order_items | order_item_id | integer | PK |
|  | order_id | integer | required FK; cascades on order deletion |
|  | product_id | integer | required FK; product deletion restricted |
|  | quantity_ordered | integer | required, positive |
|  | quantity_received | integer | required, from 0 through ordered quantity |
|  | agreed_unit_cost | numeric(12,2) | required, nonnegative |
|  | (order_id, product_id) | unique pair | one line per product on an order |
| inventory_operation_requests | request_key | uuid | PK idempotency key for retry-safe database operations |
|  | operation_name | varchar(40) | operation kind associated with the key |
|  | result | jsonb | saved result returned for a repeated request |
|  | created_at | timestamptz | request record creation timestamp |

## Entity relationships

- A category has many products; every product belongs to one category.
- A supplier can be the default supplier for many products and can receive many purchase orders.
- A product has one current balance, and many stock movements and purchase order lines.
- A purchase order has many purchase order items; each item refers to one product.

The current schema expects balance rows to be created for all products by the product creation service. `v_current_inventory` uses `LEFT JOIN` and `COALESCE` to tolerate a missing balance during setup, but application writes will create the row transactionally.

`inventory_operation_requests` is a supporting idempotency table in addition to the seven required core entities. It prevents a client retry with the same UUID from applying an operation a second time.
