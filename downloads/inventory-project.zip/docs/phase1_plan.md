# StockWise implementation plan

## Workspace inspection

The workspace was an otherwise empty Git repository. No `psql`, Docker, PostgreSQL installation, Python interpreter, or configured database credentials were found on PATH. Existing unrelated work was not present.

## Architecture

PostgreSQL 16 is the source of truth. The normalized seven-table schema is under `sql/`. Inventory balance rows are a current-position projection; stock movements are the append-only audit record. Later business operations will update the balance and append its movement within the same transaction, through a controlled SQL boundary. The Streamlit UI will call Python service functions and parameterized SQL; it will not own inventory rules.

## Phased build

1. **Database foundation (current):** schema, constraints/indexes, deterministic fictional seed, initial views, ERD and data dictionary. Verify SQL execution when PostgreSQL is available.
2. **Business logic and analytics:** controlled receipt/issue/adjustment and PO receiving functions; ten documented analytical queries; transactional verification.
3. **Python integration:** environment configuration, connection and query helpers, business services, validation and tests.
4. **Dashboard:** live-data Streamlit Overview, Product Management, Stock Control, Suppliers/Purchasing, and Reports/Exports.
5. **Testing/refinement:** isolated database tests, edge cases, transaction rollback and launch checks.
6. **Portfolio packaging:** complete findings, screenshots from a running app, clean setup review and final limitations.

## Prerequisites and initial database run

Recommended local setup is Docker Desktop with Compose, or PostgreSQL 15+ with `psql`. The included Compose file uses PostgreSQL 16.4. On Windows, once Docker Desktop is installed and running:

```powershell
Copy-Item .env.example .env
docker compose up -d
Get-Content sql/01_schema.sql | docker compose exec -T postgres psql -U stockwise_admin -d stockwise -v ON_ERROR_STOP=1
```

Apply the remaining SQL files in this order: `02_constraints_indexes.sql`, `03_seed_data.sql`, `04_views.sql`, `06_inventory_operations.sql`. Phase 1 stopped before the application. The current environment lacks prerequisites, so initialization has not yet been claimed as executed.

All supplier, product and transaction data in the seed is fictional. Rebuild an empty database to reseed; `03_seed_data.sql` intentionally does not truncate or overwrite existing data.
