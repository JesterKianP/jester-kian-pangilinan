# StockWise ERD

```mermaid
erDiagram
    CATEGORIES ||--o{ PRODUCTS : classifies
    SUPPLIERS ||--o{ PRODUCTS : default_supplier
    PRODUCTS ||--|| INVENTORY_BALANCES : current_position
    PRODUCTS ||--o{ STOCK_MOVEMENTS : audited_by
    SUPPLIERS ||--o{ PURCHASE_ORDERS : receives
    PURCHASE_ORDERS ||--|{ PURCHASE_ORDER_ITEMS : contains
    PRODUCTS ||--o{ PURCHASE_ORDER_ITEMS : ordered_as
```

![StockWise entity relationship diagram](erd.png)

The Mermaid diagram is the editable relationship source. The rendered PNG includes the seven requested core tables and the supporting idempotency-request table.
