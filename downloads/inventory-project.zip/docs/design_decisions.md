# Design decisions (Phase 1)

- PostgreSQL is the system of record. Monetary values use `numeric(12,2)` and on-hand/order quantities use integers.
- `inventory_balances` stores the current position for fast operational reads; `stock_movements` is the historical ledger. Approved SECURITY DEFINER functions update the balance and append its movement in one transaction. Ordinary application-role writes must be revoked; only approved EXECUTE grants should be assigned.
- Movement history is append-only through a trigger. Ordinary application roles must not own the schema/tables and receive execute permission on approved functions, not direct table mutation permissions.
- Product, supplier, category and movement deletion is restricted to protect history. Purchase-order lines cascade only when an order itself is removed; user-facing workflows will use cancellation rather than deletion.
- The default product supplier is represented by a foreign key. Purchase-order item cost snapshots the agreed cost at order time, avoiding later changes to product master cost from rewriting historical purchasing totals.
- Replenishment is an estimate of `max(reorder_level - quantity_on_hand, 0)`. It is threshold arithmetic, not a forecast of demand.
- The seed is deterministic and fictional. It includes 120 products, 12 suppliers, 10 categories, 40 multi-line orders and 480 dated movement records.
- `inventory_operation_requests` is a supporting idempotency table; the seven required business tables remain the core relational model.
- Timestamps use `timestamptz`; business movement/order dates use `date`.
- PO receipt calls lock the order and affected item rows, enforce outstanding limits, update receipt counts, call the stock operation, and recalculate order status atomically. Duplicate line IDs within a submission are rejected, and a UUID request key makes retries idempotent.

## Current limitation

No native PostgreSQL server/client or Docker runtime was available during this review. SQL scripts and operation behavior were exercised in embedded PostgreSQL WebAssembly; the project includes a Compose file and exact SQL apply order for native PostgreSQL verification.
