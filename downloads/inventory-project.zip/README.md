# StockWise Inventory Intelligence

PostgreSQL-first inventory management and analytics portfolio project. The database owns inventory integrity; Python services and Streamlit provide the user-facing layer.

## Current build status

- **Phase 1:** schema, indexes, deterministic fictional seed, reporting views, ERD source and data dictionary created. SQL initialization confirms zero balance-ledger mismatches and zero PO supplier-product mismatches. Native PostgreSQL 16.4 has not been run.
- **Phase 2:** controlled SQL operations and a 12-query analytics catalog created. All report queries and key operations were exercised in embedded PostgreSQL WASM, including Psycopg connections over its PostgreSQL wire socket. Native server concurrency remains to be tested.
- Python integration and the five-section Streamlit dashboard are implemented; see verification notes for native database limitations.

## Database layout

Seven normalized core tables: `categories`, `suppliers`, `products`, `inventory_balances`, `stock_movements`, `purchase_orders`, and `purchase_order_items`. See [ERD](docs/erd.md), [data dictionary](docs/data_dictionary.md), and [design decisions](docs/design_decisions.md).

`inventory_operation_requests` is a supporting table for UUID idempotency keys and saved retry results.

`inventory_balances` is the current position and `stock_movements` is the append-only audit ledger. Approved database functions perform related changes atomically. The application login must be a separate, non-owner role with only the needed `SELECT` access and `EXECUTE` grants; it must not have direct writes to inventory balances or stock movements.

## Prerequisites and setup

Recommended: Docker Desktop with Compose. `docker-compose.yml` uses PostgreSQL 16.4. Alternatively use PostgreSQL 15+ and `psql`.

```powershell
Copy-Item .env.example .env
docker compose up -d
Get-Content sql/01_schema.sql | docker compose exec -T postgres psql -U stockwise_admin -d stockwise -v ON_ERROR_STOP=1
Get-Content sql/02_constraints_indexes.sql | docker compose exec -T postgres psql -U stockwise_admin -d stockwise -v ON_ERROR_STOP=1
Get-Content sql/03_seed_data.sql | docker compose exec -T postgres psql -U stockwise_admin -d stockwise -v ON_ERROR_STOP=1
Get-Content sql/04_views.sql | docker compose exec -T postgres psql -U stockwise_admin -d stockwise -v ON_ERROR_STOP=1
Get-Content sql/06_inventory_operations.sql | docker compose exec -T postgres psql -U stockwise_admin -d stockwise -v ON_ERROR_STOP=1
```

After initialization, create a non-owner app login and grant only read access plus approved function execution (use a strong local secret in practice):

```sql
CREATE ROLE stockwise_app LOGIN PASSWORD 'replace-with-a-local-secret';
GRANT CONNECT ON DATABASE stockwise TO stockwise_app;
GRANT USAGE ON SCHEMA public TO stockwise_app;
GRANT SELECT ON categories,suppliers,products,inventory_balances,stock_movements,purchase_orders,purchase_order_items,
  v_current_inventory,v_replenishment,v_inventory_value_by_category,v_outstanding_purchase_orders TO stockwise_app;
GRANT EXECUTE ON FUNCTION stockwise_apply_movement(integer,varchar,integer,uuid,varchar,text,date) TO stockwise_app;
GRANT EXECUTE ON FUNCTION stockwise_receive_purchase_order(integer,jsonb,uuid,varchar,date) TO stockwise_app;
GRANT EXECUTE ON FUNCTION stockwise_create_product(varchar,varchar,integer,integer,numeric,numeric,integer) TO stockwise_app;
GRANT EXECUTE ON FUNCTION stockwise_update_product(integer,varchar,varchar,integer,integer,numeric,numeric,integer,boolean) TO stockwise_app;
GRANT EXECUTE ON FUNCTION stockwise_create_purchase_order(integer,date,text,jsonb) TO stockwise_app;
```

For the automated integration tests, create a separate empty native PostgreSQL database called `stockwise_test`, then set `TEST_DATABASE_URL` to it. The test fixture drops and recreates only the `public` schema in that explicitly named database before loading deterministic seed data. An embedded PGlite test server can also be used with `ALLOW_PGLITE_TEST_DATABASE=1`; the fixture verifies its PGlite/WASM identity before resetting its in-memory schema.

These scripts are for a fresh database. The seed is deterministic, fictional, and intentionally does not clear existing tables. `.env` is ignored by Git. The Compose development password is only a local placeholder; change it for any shared deployment.

## Phase 2 database operations

Run one function call per transaction. PostgreSQL rolls back all statements in a failed function call/transaction. Calls are parameterized by the eventual Python layer.

```sql
SELECT * FROM stockwise_apply_movement(17, 'issue', -2, 'c97e860a-13bb-41e2-8c0c-22bb3e5ef4c8'::uuid, 'REQ-1042', 'Order fulfillment', CURRENT_DATE);
SELECT * FROM stockwise_apply_movement(17, 'adjustment', 3, '6f2cf71e-9046-4531-b5dd-d7dad4ea238e'::uuid, 'COUNT-2026-01', 'Cycle count variance', CURRENT_DATE);
SELECT * FROM stockwise_receive_purchase_order(31, '[{"order_item_id":121,"quantity":4}]'::jsonb, '77f7a74d-6d53-40a4-a0c7-d82da69bffb9'::uuid, 'DOCK-553', CURRENT_DATE);
```

Receipt JSON contains order item IDs and positive received quantities. Each write requires a UUID request key; retrying with the same key returns the original result without applying stock twice. The caller must generate a new UUID for a new intended operation.

`sql/05_reporting_queries.sql` documents 12 practical queries: current stock, low stock, cost valuation, category value, value ranking, movement volume, monthly movement, open PO, supplier purchasing, threshold replenishment, stale movement, and category-relative cost. The final query comment provides an `EXPLAIN (ANALYZE, BUFFERS)` example; no timing is reported because it has not been run.

Example: the replenishment view returns `GREATEST(reorder_level - quantity_on_hand, 0)` for active items at or below threshold. It helps staff compare available stock with configured minimums; it does not predict future demand.

### Seed-data check (embedded PostgreSQL runtime)

The reproducible seed contains 120 active products, 12,156 units on hand, and $2,589,753.00 of active inventory value at cost. The threshold report identifies 10 low-stock and 4 out-of-stock products; 14 products meet the configured replenishment threshold. These are fixture query results, not claims about a real business.

## Project structure

```text
sql/       schema, indexes, seed, views, analytics, inventory functions
app/       Streamlit UI, database access, services, validation and reports
tests/     unit tests and guarded native PostgreSQL integration tests
docs/      ERD, data dictionary, design decisions, phase plan
```

## Dashboard screenshot status

The Streamlit server launch and health endpoint were verified. A screenshot is not included; visual capture against the connected dashboard remains outstanding.

## Python environment and dashboard

Python 3.12 is recommended. Create an environment, install the pinned packages, copy `.env.example` to `.env`, set `DATABASE_URL` to the `stockwise_app` login, and launch the Streamlit entry point:

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m streamlit run app/streamlit_app.py
```

For tests, install `requirements-dev.txt` and run `python -m pytest -q`. With native PostgreSQL, point `TEST_DATABASE_URL` at the dedicated `stockwise_test` database. This run used Psycopg over an isolated PGlite PostgreSQL wire endpoint and returned **12 passed, zero skipped**. Native PostgreSQL 16 testing remains outstanding.

Pinned runtime versions: Python 3.12, Streamlit 1.66.1, pandas 3.0.1, Plotly 7.1.0, Psycopg 3.3.6, python-dotenv 1.2.1, and pytest 9.1.1.

All companies, products, and transaction records are fictional. Replenishment quantities are threshold-based estimates, not demand forecasts. No screenshots or performance claims are included before a real application/database run.

## Skills demonstrated

- Relational modeling with primary/foreign keys, constraints, indexes, views and SQL functions.
- Inventory audit design, transactional operations, row locking, retry idempotency and rollback handling.
- SQL analysis with joins, aggregates, CTEs, CASE expressions, subqueries, date grouping and window functions.
- Python validation and database services, Pandas reporting, Plotly charts, Streamlit workflows and CSV export.
- Deterministic data seeding, isolated integration test safeguards, documentation and reproducible setup.

## Portfolio bullet examples

- Designed a normalized PostgreSQL inventory schema with seven core entities, database constraints, reporting views and a documented ERD.
- Implemented transaction-scoped stock operations that update current balances and append audit movements, with row locks and request-key idempotency.
- Built a Streamlit dashboard backed by parameterized Psycopg queries for product management, stock control, purchasing and reporting.

These bullets describe code in this repository; no customer impact, production usage, or performance improvement is claimed.

## Future improvements

- Run and document the full suite against native PostgreSQL 16, including concurrent receipt and issue tests.
- Capture dashboard screenshots after connecting the sample database and add visual UI regression coverage.
- Add authentication and role provisioning for a deployed multi-user environment.
- Add supplier lead times and demand history before building forecast-based replenishment suggestions.
- Add a scheduled cleanup policy for old idempotency request results if the application is operated long term.
