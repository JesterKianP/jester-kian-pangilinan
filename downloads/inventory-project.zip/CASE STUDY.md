# Inventory Reporting

A PostgreSQL inventory project with a Python and Streamlit interface for product records, stock movements, purchasing, and reporting.

## Task

Organize inventory information and preserve a traceable stock-movement history.

## Workflow

Maintain product records, record stock operations, track purchase orders, and review inventory and replenishment reports.

## Technical evidence

Seven core relational tables, an ERD and data dictionary, 12 reporting queries, and controlled database functions for stock operations.

## Review the work

Start with docs/erd.png and docs/data_dictionary.md in Projects/03 Inventory Reporting. Read sql/05_reporting_queries.sql. The README contains database and dashboard setup steps.

## Verification scope

Current local test run: 6 passed and 6 database integration tests skipped because no test database was configured. Native PostgreSQL concurrency and connected dashboard screenshots remain unverified.
