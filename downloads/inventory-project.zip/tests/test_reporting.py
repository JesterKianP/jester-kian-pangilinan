import pandas as pd

from app.reporting import dataframe_csv


def test_csv_exports_values_and_headers():
    result = dataframe_csv(pd.DataFrame([{"sku":"SW-1","units":2}])).decode("utf-8-sig")
    assert result == "sku,units\nSW-1,2\n"


def test_empty_csv_keeps_column_headers():
    result = dataframe_csv(pd.DataFrame(columns=["sku","units"])).decode("utf-8-sig")
    assert result == "sku,units\n"
