"""Integration fixtures only reset a database explicitly named stockwise_test."""
import os
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture(scope="session")
def test_db():
    url = os.getenv("TEST_DATABASE_URL")
    if not url:
        pytest.skip("Set TEST_DATABASE_URL to a dedicated database named stockwise_test to run PostgreSQL integration tests.")
    import psycopg
    from urllib.parse import urlparse
    database_name = urlparse(url).path.lstrip("/").split("?",1)[0]
    if database_name != "stockwise_test":
        pytest.fail("Refusing destructive integration setup: TEST_DATABASE_URL database name must be exactly stockwise_test.")
    from psycopg.rows import dict_row
    # PGlite's PostgreSQL wire adapter does not reliably reset prepared-statement
    # state after a server-side error; avoid Psycopg's automatic prepare there.
    conn = psycopg.connect(url, autocommit=True, row_factory=dict_row, prepare_threshold=None)
    try:
        server = conn.execute("SELECT current_database() AS database_name, version() AS server_version").fetchone()
        is_isolated_pglite = (
            os.getenv("ALLOW_PGLITE_TEST_DATABASE") == "1"
            and server["database_name"] == "postgres"
            and ("pglite" in server["server_version"].lower() or "wasm32" in server["server_version"].lower())
        )
        if server["database_name"] != "stockwise_test" and not is_isolated_pglite:
            pytest.fail("Refusing destructive integration setup: connected server database must be stockwise_test. PGlite requires explicit ALLOW_PGLITE_TEST_DATABASE=1.")
        conn.execute("DROP SCHEMA public CASCADE; CREATE SCHEMA public")
        for filename in ("01_schema.sql","02_constraints_indexes.sql","03_seed_data.sql","04_views.sql","05_reporting_queries.sql","06_inventory_operations.sql"):
            conn.execute((ROOT / "sql" / filename).read_text(encoding="utf-8"))
        yield conn
    finally:
        conn.close()


@pytest.fixture
def db(test_db):
    # Each integration test restores the deterministic fixture state.
    test_db.execute("TRUNCATE inventory_operation_requests, stock_movements, purchase_order_items, purchase_orders, inventory_balances, products, suppliers, categories RESTART IDENTITY CASCADE")
    for filename in ("03_seed_data.sql",):
        test_db.execute((ROOT / "sql" / filename).read_text(encoding="utf-8"))
    return test_db
