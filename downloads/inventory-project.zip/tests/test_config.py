import pytest

from app.config import Settings


def test_missing_database_configuration_is_clear(monkeypatch):
    monkeypatch.delenv("DATABASE_URL", raising=False)
    with pytest.raises(RuntimeError, match="DATABASE_URL is required"):
        Settings.from_env()


def test_non_postgresql_url_is_rejected(monkeypatch):
    monkeypatch.setenv("DATABASE_URL", "sqlite:///not_supported.db")
    with pytest.raises(RuntimeError, match="must use PostgreSQL"):
        Settings.from_env()
