from decimal import Decimal

from app.validation import validate_product


def test_valid_product_passes_validation():
    assert validate_product(sku="SW-9999", product_name="Storage Bin", unit_cost=Decimal("4.25"), unit_price="6.99", reorder_level=8) == []


def test_required_fields_and_negative_values_are_rejected():
    errors = validate_product(sku=" ", product_name="", unit_cost="-1", unit_price="bad", reorder_level=-2)
    assert len(errors) == 5
