"""Destructive database behavior is isolated to the guarded stockwise_test DB."""
import uuid
import json

import pytest


def test_schema_seed_and_balance_ledger_reconcile(db):
    assert db.execute("SELECT count(*) AS n FROM products").fetchone()["n"] == 120
    assert db.execute("SELECT count(*) AS n FROM purchase_orders").fetchone()["n"] == 40
    mismatch = db.execute("SELECT count(*) AS n FROM inventory_balances b WHERE b.quantity_on_hand <> (SELECT COALESCE(sum(m.quantity_delta),0) FROM stock_movements m WHERE m.product_id=b.product_id)").fetchone()["n"]
    assert mismatch == 0
    bad_supplier_lines=db.execute("SELECT count(*) AS n FROM purchase_order_items i JOIN purchase_orders po USING(order_id) JOIN products p USING(product_id) WHERE po.supplier_id<>p.supplier_id").fetchone()["n"]
    assert bad_supplier_lines==0


def test_duplicate_sku_and_constraints_reject_invalid_values(db):
    with pytest.raises(Exception):
        db.execute("INSERT INTO products(sku,product_name,category_id,supplier_id,unit_cost,unit_price) VALUES('SW-0001','Dup',1,1,1,1)")
    with pytest.raises(Exception):
        db.execute("INSERT INTO products(sku,product_name,category_id,supplier_id,unit_cost,unit_price) VALUES('BAD-PRICE','Bad',1,1,-1,1)")
    with pytest.raises(Exception):
        db.execute("INSERT INTO products(sku,product_name,category_id,supplier_id,unit_cost,unit_price) VALUES('BAD-FK','Bad',999,1,1,1)")


def test_issue_receipt_adjustment_and_idempotency(db):
    product_id = db.execute("SELECT product_id FROM inventory_balances WHERE quantity_on_hand > 10 LIMIT 1").fetchone()["product_id"]
    key = uuid.uuid4()
    before = db.execute("SELECT quantity_on_hand FROM inventory_balances WHERE product_id=%s",(product_id,)).fetchone()["quantity_on_hand"]
    first=db.execute("SELECT * FROM stockwise_apply_movement(%s,'issue',-2,%s,'TEST-ISSUE',NULL,CURRENT_DATE)",(product_id,key)).fetchone()
    second=db.execute("SELECT * FROM stockwise_apply_movement(%s,'issue',-2,%s,'TEST-ISSUE',NULL,CURRENT_DATE)",(product_id,key)).fetchone()
    assert first == second
    assert db.execute("SELECT quantity_on_hand FROM inventory_balances WHERE product_id=%s",(product_id,)).fetchone()["quantity_on_hand"] == before-2
    with pytest.raises(Exception):
        db.execute("SELECT * FROM stockwise_apply_movement(%s,'issue',-999999,%s,NULL,NULL,CURRENT_DATE)",(product_id,uuid.uuid4()))
    movement_count=db.execute("SELECT count(*) AS n FROM stock_movements WHERE product_id=%s",(product_id,)).fetchone()["n"]
    assert movement_count >= 1
    adjusted=db.execute("SELECT * FROM stockwise_apply_movement(%s,'adjustment',1,%s,'CYCLE-1','Count correction',CURRENT_DATE)",(product_id,uuid.uuid4())).fetchone()
    assert adjusted["quantity_on_hand"] == before-1


def test_purchase_receipt_limit_status_idempotency_and_rollback(db):
    order_id=db.execute("SELECT order_id FROM purchase_orders WHERE status='ordered' LIMIT 1").fetchone()["order_id"]
    line=db.execute("SELECT order_item_id,quantity_ordered,quantity_received,product_id FROM purchase_order_items WHERE order_id=%s ORDER BY order_item_id LIMIT 1",(order_id,)).fetchone()
    lines=db.execute("SELECT order_item_id,quantity_ordered,quantity_received,product_id FROM purchase_order_items WHERE order_id=%s ORDER BY order_item_id LIMIT 2",(order_id,)).fetchall()
    before_balances={row["product_id"]:db.execute("SELECT quantity_on_hand FROM inventory_balances WHERE product_id=%s",(row["product_id"],)).fetchone()["quantity_on_hand"] for row in lines}
    before_movements=db.execute("SELECT count(*) AS n FROM stock_movements").fetchone()["n"]
    invalid_payload=json.dumps([{"order_item_id":lines[0]["order_item_id"],"quantity":1},{"order_item_id":lines[1]["order_item_id"],"quantity":lines[1]["quantity_ordered"]+1}])
    with pytest.raises(Exception):
        db.execute("SELECT * FROM stockwise_receive_purchase_order(%s,%s::jsonb,%s,'PO-ROLLBACK',CURRENT_DATE)",(order_id,invalid_payload,uuid.uuid4()))
    assert db.execute("SELECT count(*) AS n FROM stock_movements").fetchone()["n"]==before_movements
    for product_id,quantity in before_balances.items():
        assert db.execute("SELECT quantity_on_hand FROM inventory_balances WHERE product_id=%s",(product_id,)).fetchone()["quantity_on_hand"]==quantity
    assert db.execute("SELECT quantity_received FROM purchase_order_items WHERE order_item_id=%s",(lines[0]["order_item_id"],)).fetchone()["quantity_received"]==lines[0]["quantity_received"]
    qty=2
    key=uuid.uuid4()
    payload=json.dumps([{"order_item_id":line["order_item_id"],"quantity":qty}])
    first=db.execute("SELECT * FROM stockwise_receive_purchase_order(%s,%s::jsonb,%s,'PO-TEST',CURRENT_DATE)",(order_id,payload,key)).fetchone()
    again=db.execute("SELECT * FROM stockwise_receive_purchase_order(%s,%s::jsonb,%s,'PO-TEST',CURRENT_DATE)",(order_id,payload,key)).fetchone()
    assert first == again
    current=db.execute("SELECT quantity_received FROM purchase_order_items WHERE order_item_id=%s",(line["order_item_id"],)).fetchone()["quantity_received"]
    assert current == qty
    with pytest.raises(Exception):
        db.execute("SELECT * FROM stockwise_receive_purchase_order(%s,%s::jsonb,%s,NULL,CURRENT_DATE)",(order_id,json.dumps([{"order_item_id":line["order_item_id"],"quantity":line["quantity_ordered"]}]),uuid.uuid4()))
    assert db.execute("SELECT quantity_received FROM purchase_order_items WHERE order_item_id=%s",(line["order_item_id"],)).fetchone()["quantity_received"] == qty
    remaining=db.execute("SELECT order_item_id,quantity_ordered,quantity_received FROM purchase_order_items WHERE order_id=%s AND quantity_received<quantity_ordered",(order_id,)).fetchall()
    completion=json.dumps([{"order_item_id":row["order_item_id"],"quantity":row["quantity_ordered"]-row["quantity_received"]} for row in remaining])
    final=db.execute("SELECT * FROM stockwise_receive_purchase_order(%s,%s::jsonb,%s,'PO-TEST-COMPLETE',CURRENT_DATE)",(order_id,completion,uuid.uuid4())).fetchone()
    assert final["status"]=="received"


def test_reporting_view_and_product_creation(db):
    count=db.execute("SELECT count(*) AS n FROM v_current_inventory").fetchone()["n"]
    assert count==120
    metrics=db.execute("SELECT count(*) FILTER(WHERE stock_status='low_stock') low,count(*) FILTER(WHERE stock_status='out_of_stock') out FROM v_current_inventory WHERE active").fetchone()
    assert metrics=={"low":10,"out":4}
    assert db.execute("SELECT count(*) AS n FROM v_replenishment").fetchone()["n"]==14
    product_id=db.execute("SELECT stockwise_create_product('TEST-NEW','Test New',1,1,1.00,2.00,3)").fetchone()["stockwise_create_product"]
    assert db.execute("SELECT quantity_on_hand FROM inventory_balances WHERE product_id=%s",(product_id,)).fetchone()["quantity_on_hand"]==0
    db.execute("SELECT stockwise_update_product(%s,'TEST-EDIT','Edited Product',2,2,1.25,2.50,9,true)",(product_id,))
    edited=db.execute("SELECT sku,product_name,category_id,supplier_id FROM products WHERE product_id=%s",(product_id,)).fetchone()
    assert edited=={"sku":"TEST-EDIT","product_name":"Edited Product","category_id":2,"supplier_id":2}


def test_purchase_order_creation_validates_supplier_products_and_lines(db):
    created=db.execute("SELECT stockwise_create_purchase_order(1,CURRENT_DATE+14,'test',%s::jsonb) AS order_id",(json.dumps([{"product_id":1,"quantity_ordered":5,"agreed_unit_cost":"1.25"},{"product_id":13,"quantity_ordered":7,"agreed_unit_cost":"2.50"}]),)).fetchone()["order_id"]
    assert db.execute("SELECT status FROM purchase_orders WHERE order_id=%s",(created,)).fetchone()["status"]=="ordered"
    assert db.execute("SELECT count(*) AS n FROM purchase_order_items WHERE order_id=%s",(created,)).fetchone()["n"]==2
    with pytest.raises(Exception):
        db.execute("SELECT stockwise_create_purchase_order(1,CURRENT_DATE+14,'bad supplier',%s::jsonb)",(json.dumps([{"product_id":2,"quantity_ordered":1,"agreed_unit_cost":"1.00"}]),))
    with pytest.raises(Exception):
        db.execute("SELECT stockwise_create_purchase_order(1,CURRENT_DATE+14,'empty',NULL::jsonb)")
