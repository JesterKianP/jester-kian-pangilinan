-- Supporting indexes not already provided by primary/unique constraints.
CREATE INDEX products_category_active_idx ON products(category_id, active);
CREATE INDEX products_supplier_active_idx ON products(supplier_id, active);
CREATE INDEX products_name_idx ON products(product_name);
CREATE INDEX stock_movements_product_date_idx ON stock_movements(product_id, movement_date DESC, movement_id DESC);
CREATE INDEX stock_movements_date_type_idx ON stock_movements(movement_date, movement_type);
CREATE INDEX purchase_orders_supplier_status_date_idx ON purchase_orders(supplier_id, status, order_date DESC);
CREATE INDEX purchase_orders_expected_date_idx ON purchase_orders(expected_date) WHERE status IN ('ordered','partially_received');
CREATE INDEX purchase_order_items_product_idx ON purchase_order_items(product_id);
