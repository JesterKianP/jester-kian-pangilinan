-- StockWise business analytics catalog (PostgreSQL 15+).
-- Each query includes its business purpose and interpretation. Run against seeded data.

-- 1. Current inventory by product, category and supplier.
-- Purpose: operational inventory list. Interpret quantity with the explicit status.
SELECT sku,product_name,category_name,supplier_name,quantity_on_hand,reorder_level,stock_status
FROM v_current_inventory WHERE active ORDER BY category_name,product_name;

-- 2. Low-stock and out-of-stock products.
-- Purpose: focus attention on products at/below their configured threshold.
SELECT sku,product_name,category_name,supplier_name,quantity_on_hand,reorder_level,stock_status
FROM v_current_inventory WHERE active AND stock_status IN ('low_stock','out_of_stock')
ORDER BY quantity_on_hand,product_name;

-- 3. Total active inventory value at cost.
-- Purpose: estimate capital currently held in active stock; not retail value.
SELECT COALESCE(SUM(inventory_value_at_cost),0)::numeric(14,2) AS total_inventory_value_at_cost
FROM v_current_inventory WHERE active;

-- 4. Inventory value by category.
-- Purpose: compare cost value held across product groups.
SELECT category_name,active_product_count,inventory_value_at_cost
FROM v_inventory_value_by_category ORDER BY inventory_value_at_cost DESC;

-- 5. Products ranked by inventory value.
-- Purpose: identify items contributing the most cost value; window rank handles ties.
SELECT sku,product_name,category_name,quantity_on_hand,inventory_value_at_cost,
       DENSE_RANK() OVER (ORDER BY inventory_value_at_cost DESC) AS value_rank
FROM v_current_inventory WHERE active ORDER BY value_rank,sku;

-- 6. Products with the highest movement volume in a selected interval.
-- Purpose: find operationally active items; absolute quantities include receipts and issues.
WITH movement_volume AS (
  SELECT p.product_id,p.sku,p.product_name,COUNT(m.movement_id) AS movement_count,
         SUM(abs(m.quantity_delta)) AS units_moved
  FROM products p LEFT JOIN stock_movements m ON m.product_id=p.product_id
       AND m.movement_date >= CURRENT_DATE - INTERVAL '90 days'
  GROUP BY p.product_id,p.sku,p.product_name
)
SELECT *,ROW_NUMBER() OVER (ORDER BY units_moved DESC,movement_count DESC,sku) AS activity_rank
FROM movement_volume ORDER BY activity_rank LIMIT 20;

-- 7. Monthly receipts, issues and adjustments for the prior 12 months.
-- Purpose: show gross flow by movement type, retaining months with activity only.
SELECT date_trunc('month',movement_date)::date AS month,
       SUM(quantity_delta) FILTER (WHERE movement_type='receipt') AS receipt_units,
       -SUM(quantity_delta) FILTER (WHERE movement_type='issue') AS issue_units,
       SUM(quantity_delta) FILTER (WHERE movement_type='adjustment') AS net_adjustment_units
FROM stock_movements
WHERE movement_date >= date_trunc('month',CURRENT_DATE) - INTERVAL '11 months'
GROUP BY 1 ORDER BY 1;

-- 8. Outstanding purchase orders by supplier.
-- Purpose: review unreceived commitments, with line counts and cost estimate.
SELECT supplier_name,COUNT(*) AS open_order_count,SUM(outstanding_value)::numeric(14,2) AS outstanding_value
FROM v_outstanding_purchase_orders GROUP BY supplier_name HAVING SUM(outstanding_value)>0
ORDER BY outstanding_value DESC;

-- 9. Supplier purchasing summary for received quantities.
-- Purpose: summarize accepted units and agreed cost since a configurable date.
SELECT s.supplier_name,COUNT(DISTINCT po.order_id) AS order_count,
       SUM(poi.quantity_received) AS units_received,
       SUM(poi.quantity_received*poi.agreed_unit_cost)::numeric(14,2) AS received_cost
FROM suppliers s JOIN purchase_orders po ON po.supplier_id=s.supplier_id
JOIN purchase_order_items poi ON poi.order_id=po.order_id
WHERE po.status <> 'cancelled' AND po.order_date >= CURRENT_DATE - INTERVAL '1 year'
GROUP BY s.supplier_name ORDER BY received_cost DESC NULLS LAST;

-- 10. Threshold-based replenishment recommendations (estimates, not forecasts).
-- Purpose: calculate the units needed to return to configured reorder levels.
SELECT sku,product_name,category_name,supplier_name,quantity_on_hand,reorder_level,
       estimated_replenishment_quantity,
       CASE WHEN quantity_on_hand=0 THEN 'urgent: out of stock' ELSE 'review replenishment' END AS recommendation
FROM v_replenishment ORDER BY quantity_on_hand,estimated_replenishment_quantity DESC;

-- 11. Products without movements in 90 days, while preserving never-moved products.
-- Purpose: surface inactive inventory and demonstrate LEFT JOIN / NULL handling.
SELECT p.sku,p.product_name,MAX(m.movement_date) AS last_movement_date,
       COALESCE(CURRENT_DATE-MAX(m.movement_date),99999) AS days_since_movement
FROM products p LEFT JOIN stock_movements m ON m.product_id=p.product_id
GROUP BY p.product_id,p.sku,p.product_name
HAVING MAX(m.movement_date) IS NULL OR MAX(m.movement_date)<CURRENT_DATE-90
ORDER BY last_movement_date NULLS FIRST;

-- 12. Product costs above their category average (subquery and CTE).
-- Purpose: compare cost positioning within product groups.
WITH category_cost AS (
  SELECT category_id,AVG(unit_cost) AS avg_cost FROM products WHERE active GROUP BY category_id
)
SELECT p.sku,p.product_name,c.category_name,p.unit_cost,cc.avg_cost
FROM products p JOIN categories c USING(category_id) JOIN category_cost cc USING(category_id)
WHERE p.active AND p.unit_cost>cc.avg_cost ORDER BY c.category_name,p.unit_cost DESC;

-- Representative plan inspection (do not publish a timing without executing locally):
-- EXPLAIN (ANALYZE, BUFFERS) SELECT * FROM v_current_inventory WHERE active AND quantity_on_hand<=reorder_level;
