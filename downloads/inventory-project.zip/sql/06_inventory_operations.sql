-- Controlled inventory operations. Run after 01_schema.sql.
-- The table owner owns these SECURITY DEFINER functions. The application login
-- must not own tables or be a member of the owner role; it receives EXECUTE only.
CREATE OR REPLACE FUNCTION stockwise_apply_movement(
    p_product_id integer,
    p_movement_type varchar,
    p_quantity_delta integer,
    p_request_key uuid,
    p_reference varchar DEFAULT NULL,
    p_notes text DEFAULT NULL,
    p_movement_date date DEFAULT CURRENT_DATE
) RETURNS TABLE(movement_id bigint, product_id integer, quantity_on_hand integer)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE v_old_qty integer;
DECLARE v_new_qty integer;
DECLARE v_movement_id bigint;
DECLARE v_prior jsonb;
BEGIN
    IF p_request_key IS NULL THEN RAISE EXCEPTION 'An idempotency request key is required' USING ERRCODE='22023'; END IF;
    INSERT INTO public.inventory_operation_requests(request_key,operation_name)
    VALUES(p_request_key,'stock_movement') ON CONFLICT DO NOTHING;
    IF NOT FOUND THEN
        SELECT result INTO v_prior FROM public.inventory_operation_requests WHERE request_key=p_request_key FOR UPDATE;
        IF v_prior IS NULL OR v_prior->>'operation' <> 'stock_movement' THEN RAISE EXCEPTION 'Request key is already in use' USING ERRCODE='23505'; END IF;
        RETURN QUERY SELECT (v_prior->>'movement_id')::bigint,(v_prior->>'product_id')::integer,(v_prior->>'quantity_on_hand')::integer;
        RETURN;
    END IF;
    IF p_quantity_delta = 0 OR p_movement_type NOT IN ('receipt','issue','adjustment') THEN
        RAISE EXCEPTION 'Invalid movement type or zero quantity' USING ERRCODE='22023';
    END IF;
    IF (p_movement_type='receipt' AND p_quantity_delta<0) OR
       (p_movement_type='issue' AND p_quantity_delta>0) THEN
        RAISE EXCEPTION 'Receipt must be positive and issue must be negative' USING ERRCODE='22023';
    END IF;
    IF p_movement_type='adjustment' AND NULLIF(btrim(p_reference),'') IS NULL AND NULLIF(btrim(p_notes),'') IS NULL THEN
        RAISE EXCEPTION 'Adjustment requires a reason or reference' USING ERRCODE='22023';
    END IF;

    SELECT b.quantity_on_hand INTO v_old_qty
    FROM public.inventory_balances b WHERE b.product_id=p_product_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Inventory balance not found for product %', p_product_id USING ERRCODE='P0002'; END IF;
    v_new_qty := v_old_qty + p_quantity_delta;
    IF v_new_qty < 0 THEN RAISE EXCEPTION 'Insufficient stock: available %, requested %', v_old_qty, -p_quantity_delta USING ERRCODE='23514'; END IF;

    UPDATE public.inventory_balances AS b SET quantity_on_hand=v_new_qty,last_updated=now() WHERE b.product_id=p_product_id;
    INSERT INTO public.stock_movements(product_id,movement_type,quantity_delta,reference,notes,movement_date,request_key)
        VALUES(p_product_id,p_movement_type,p_quantity_delta,p_reference,p_notes,COALESCE(p_movement_date,CURRENT_DATE),p_request_key)
        RETURNING stock_movements.movement_id INTO v_movement_id;
    UPDATE public.inventory_operation_requests SET result=jsonb_build_object('operation','stock_movement','movement_id',v_movement_id,'product_id',p_product_id,'quantity_on_hand',v_new_qty)
    WHERE request_key=p_request_key;
    RETURN QUERY SELECT v_movement_id,p_product_id,v_new_qty;
END;
$$;

CREATE OR REPLACE FUNCTION stockwise_receive_purchase_order(
    p_order_id integer,
    p_receipts jsonb,
    p_request_key uuid,
    p_reference varchar DEFAULT NULL,
    p_received_date date DEFAULT CURRENT_DATE
) RETURNS TABLE(order_id integer, status varchar, received_line_count integer)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE v_status varchar(20);
DECLARE v_line record;
DECLARE v_count integer := 0;
DECLARE v_new_received integer;
DECLARE v_total_lines integer;
DECLARE v_complete_lines integer;
DECLARE v_prior jsonb;
BEGIN
    IF p_request_key IS NULL THEN RAISE EXCEPTION 'An idempotency request key is required' USING ERRCODE='22023'; END IF;
    INSERT INTO public.inventory_operation_requests(request_key,operation_name)
    VALUES(p_request_key,'purchase_order_receipt') ON CONFLICT DO NOTHING;
    IF NOT FOUND THEN
        SELECT result INTO v_prior FROM public.inventory_operation_requests WHERE request_key=p_request_key FOR UPDATE;
        IF v_prior IS NULL OR v_prior->>'operation' <> 'purchase_order_receipt' THEN RAISE EXCEPTION 'Request key is already in use' USING ERRCODE='23505'; END IF;
        order_id := (v_prior->>'order_id')::integer; status := v_prior->>'status'; received_line_count := (v_prior->>'received_line_count')::integer;
        RETURN NEXT; RETURN;
    END IF;
    IF p_receipts IS NULL OR jsonb_typeof(p_receipts) <> 'array' OR jsonb_array_length(p_receipts)=0 THEN
        RAISE EXCEPTION 'Provide a non-empty receipt list' USING ERRCODE='22023';
    END IF;
    IF EXISTS (
        SELECT 1 FROM jsonb_to_recordset(p_receipts) AS x(order_item_id integer, quantity integer)
        GROUP BY x.order_item_id HAVING count(*)>1
    ) THEN RAISE EXCEPTION 'Receipt list contains duplicate order items' USING ERRCODE='22023'; END IF;
    SELECT po.status INTO v_status FROM public.purchase_orders po WHERE po.order_id=p_order_id FOR UPDATE;
    IF NOT FOUND THEN RAISE EXCEPTION 'Purchase order % not found',p_order_id USING ERRCODE='P0002'; END IF;
    IF v_status NOT IN ('ordered','partially_received') THEN
        RAISE EXCEPTION 'Cannot receive purchase order in status %',v_status USING ERRCODE='23514';
    END IF;

    FOR v_line IN
        SELECT x.order_item_id, x.quantity, poi.product_id, poi.quantity_ordered, poi.quantity_received
        FROM jsonb_to_recordset(p_receipts) AS x(order_item_id integer, quantity integer)
        JOIN public.purchase_order_items poi ON poi.order_item_id=x.order_item_id AND poi.order_id=p_order_id
        ORDER BY poi.product_id FOR UPDATE OF poi
    LOOP
        IF v_line.quantity IS NULL OR v_line.quantity <= 0 THEN RAISE EXCEPTION 'Receipt quantities must be positive' USING ERRCODE='22023'; END IF;
        IF v_line.quantity > v_line.quantity_ordered-v_line.quantity_received THEN
            RAISE EXCEPTION 'Receipt exceeds outstanding quantity for order item %',v_line.order_item_id USING ERRCODE='23514';
        END IF;
        v_new_received := v_line.quantity_received + v_line.quantity;
        UPDATE public.purchase_order_items SET quantity_received=v_new_received WHERE order_item_id=v_line.order_item_id;
        PERFORM public.stockwise_apply_movement(v_line.product_id,'receipt',v_line.quantity,gen_random_uuid(),
                 COALESCE(NULLIF(btrim(p_reference),''),'PO-'||p_order_id),
                 'Receipt against purchase order '||p_order_id,COALESCE(p_received_date,CURRENT_DATE));
        v_count := v_count+1;
    END LOOP;
    IF v_count <> jsonb_array_length(p_receipts) THEN
        RAISE EXCEPTION 'Receipt contains an unknown or duplicate order item' USING ERRCODE='22023';
    END IF;

    SELECT count(*), count(*) FILTER (WHERE quantity_received=quantity_ordered)
    INTO v_total_lines,v_complete_lines FROM public.purchase_order_items WHERE purchase_order_items.order_id=p_order_id;
    IF v_total_lines=0 THEN RAISE EXCEPTION 'Purchase order has no items' USING ERRCODE='23514'; END IF;
    UPDATE public.purchase_orders SET status=CASE WHEN v_total_lines=v_complete_lines THEN 'received' ELSE 'partially_received' END,
                               updated_at=now()
    WHERE public.purchase_orders.order_id=p_order_id
    RETURNING public.purchase_orders.order_id,public.purchase_orders.status INTO order_id,status;
    received_line_count := v_count;
    UPDATE public.inventory_operation_requests SET result=jsonb_build_object('operation','purchase_order_receipt','order_id',order_id,'status',status,'received_line_count',received_line_count)
    WHERE request_key=p_request_key;
    RETURN NEXT;
END;
$$;

-- Product creation must initialize the balance in the same database call.
CREATE OR REPLACE FUNCTION stockwise_create_product(
    p_sku varchar, p_product_name varchar, p_category_id integer, p_supplier_id integer,
    p_unit_cost numeric, p_unit_price numeric, p_reorder_level integer
) RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE v_product_id integer;
BEGIN
    INSERT INTO public.products(sku,product_name,category_id,supplier_id,unit_cost,unit_price,reorder_level)
    VALUES(p_sku,p_product_name,p_category_id,p_supplier_id,p_unit_cost,p_unit_price,p_reorder_level)
    RETURNING product_id INTO v_product_id;
    INSERT INTO public.inventory_balances(product_id,quantity_on_hand) VALUES(v_product_id,0);
    RETURN v_product_id;
END;
$$;

CREATE OR REPLACE FUNCTION stockwise_update_product(
    p_product_id integer,p_sku varchar,p_product_name varchar,p_category_id integer,p_supplier_id integer,
    p_unit_cost numeric,p_unit_price numeric,p_reorder_level integer,p_active boolean
) RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
BEGIN
    UPDATE public.products SET sku=p_sku,product_name=p_product_name,category_id=p_category_id,supplier_id=p_supplier_id,unit_cost=p_unit_cost,
        unit_price=p_unit_price,reorder_level=p_reorder_level,active=p_active,updated_at=now()
    WHERE product_id=p_product_id;
    IF NOT FOUND THEN RAISE EXCEPTION 'Product % not found',p_product_id USING ERRCODE='P0002'; END IF;
END;
$$;

CREATE OR REPLACE FUNCTION stockwise_create_purchase_order(
    p_supplier_id integer,p_expected_date date,p_notes text,p_items jsonb
) RETURNS integer LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog, public, pg_temp AS $$
DECLARE v_order_id integer;
DECLARE v_line record;
DECLARE v_count integer := 0;
BEGIN
    IF p_items IS NULL OR jsonb_typeof(p_items)<>'array' OR jsonb_array_length(p_items)=0 THEN
        RAISE EXCEPTION 'A purchase order requires at least one item' USING ERRCODE='22023';
    END IF;
    IF EXISTS (SELECT 1 FROM jsonb_to_recordset(p_items) x(product_id integer,quantity_ordered integer,agreed_unit_cost numeric)
               GROUP BY product_id HAVING count(*)>1) THEN
        RAISE EXCEPTION 'A product may appear only once on a purchase order' USING ERRCODE='22023';
    END IF;
    INSERT INTO public.purchase_orders(supplier_id,expected_date,status,notes)
    VALUES(p_supplier_id,p_expected_date,'ordered',p_notes) RETURNING order_id INTO v_order_id;
    FOR v_line IN SELECT * FROM jsonb_to_recordset(p_items)
        AS x(product_id integer,quantity_ordered integer,agreed_unit_cost numeric) ORDER BY product_id
    LOOP
        IF v_line.quantity_ordered IS NULL OR v_line.quantity_ordered<=0 OR v_line.agreed_unit_cost IS NULL OR v_line.agreed_unit_cost<0 THEN
            RAISE EXCEPTION 'Order quantities must be positive and costs nonnegative' USING ERRCODE='22023';
        END IF;
        IF NOT EXISTS (SELECT 1 FROM public.products WHERE product_id=v_line.product_id AND supplier_id=p_supplier_id AND active) THEN
            RAISE EXCEPTION 'Product % is not active or is not assigned to this supplier',v_line.product_id USING ERRCODE='23514';
        END IF;
        INSERT INTO public.purchase_order_items(order_id,product_id,quantity_ordered,agreed_unit_cost)
        VALUES(v_order_id,v_line.product_id,v_line.quantity_ordered,v_line.agreed_unit_cost);
        v_count:=v_count+1;
    END LOOP;
    RETURN v_order_id;
END;
$$;

REVOKE ALL ON FUNCTION stockwise_apply_movement(integer,varchar,integer,uuid,varchar,text,date) FROM PUBLIC;
REVOKE ALL ON FUNCTION stockwise_receive_purchase_order(integer,jsonb,uuid,varchar,date) FROM PUBLIC;
REVOKE ALL ON FUNCTION stockwise_create_product(varchar,varchar,integer,integer,numeric,numeric,integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION stockwise_update_product(integer,varchar,varchar,integer,integer,numeric,numeric,integer,boolean) FROM PUBLIC;
REVOKE ALL ON FUNCTION stockwise_create_purchase_order(integer,date,text,jsonb) FROM PUBLIC;
-- Grant EXECUTE to the dedicated application role after creating it:
-- GRANT EXECUTE ON FUNCTION stockwise_apply_movement(integer,varchar,integer,uuid,varchar,text,date) TO stockwise_app;
-- GRANT EXECUTE ON FUNCTION stockwise_receive_purchase_order(integer,jsonb,uuid,varchar,date) TO stockwise_app;
-- GRANT EXECUTE ON FUNCTION stockwise_create_product(varchar,varchar,integer,integer,numeric,numeric,integer) TO stockwise_app;
-- GRANT EXECUTE ON FUNCTION stockwise_update_product(integer,varchar,varchar,integer,integer,numeric,numeric,integer,boolean) TO stockwise_app;
-- GRANT EXECUTE ON FUNCTION stockwise_create_purchase_order(integer,date,text,jsonb) TO stockwise_app;
