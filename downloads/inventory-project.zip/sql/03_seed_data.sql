-- Deterministic fictional demo data. Safe to rerun on an empty schema only.
BEGIN;
INSERT INTO categories(category_id,category_name,description) VALUES
(1,'Office Supplies','Paper, writing and desk essentials'),(2,'Electronics','Computers and peripherals'),
(3,'Furniture','Office furniture'),(4,'Safety','Personal protective equipment'),
(5,'Packaging','Shipping materials'),(6,'Cleaning','Janitorial supplies'),
(7,'Tools','Maintenance tools'),(8,'Breakroom','Food service and kitchen supplies'),
(9,'Networking','Network infrastructure'),(10,'Storage','Storage and organization');

INSERT INTO suppliers(supplier_id,supplier_name,contact_name,contact_email,phone,address,active) VALUES
(1,'Northstar Office Co.','Maya Chen','maya@northstar.example','555-0101','Portland, OR',true),
(2,'Summit Tech Supply','Evan Brooks','evan@summit.example','555-0102','Seattle, WA',true),
(3,'Cedar & Steel Furnishings','Nina Patel','nina@cedarsteel.example','555-0103','Boise, ID',true),
(4,'SafePath Industrial','Luis Romero','luis@safepath.example','555-0104','Denver, CO',true),
(5,'ParcelPro Packaging','Ava Martin','ava@parcelpro.example','555-0105','Reno, NV',true),
(6,'BrightWorks Janitorial','Noah Kim','noah@brightworks.example','555-0106','Sacramento, CA',true),
(7,'ToolHouse Direct','Ella Wright','ella@toolhouse.example','555-0107','Phoenix, AZ',true),
(8,'CommonGround Breakroom','Omar Ali','omar@commonground.example','555-0108','Salt Lake City, UT',true),
(9,'WestLink Networks','Zoe Turner','zoe@westlink.example','555-0109','San Jose, CA',true),
(10,'Modular Storage Works','Leo Garcia','leo@modular.example','555-0110','Las Vegas, NV',true),
(11,'Evergreen Business Goods','Iris Hall','iris@evergreen.example','555-0111','Eugene, OR',true),
(12,'Apex Wholesale Partners','Theo Baker','theo@apex.example','555-0112','Los Angeles, CA',true);

INSERT INTO products(product_id,sku,product_name,category_id,supplier_id,unit_cost,unit_price,reorder_level,active,created_at,updated_at)
SELECT n, 'SW-'||lpad(n::text,4,'0'),
       (ARRAY['Premium Copy Paper','Wireless Mouse','Ergonomic Task Chair','Nitrile Gloves','Corrugated Mailer','Multi-Surface Cleaner','Precision Driver Set','Compostable Cups','Gigabit Switch','Stackable Storage Bin'])[ ((n-1)%10)+1 ] || ' ' || lpad(n::text,3,'0'),
       ((n-1)%10)+1, ((n-1)%12)+1,
       (5 + ((n*17)%420) + ((n%4)*0.25))::numeric(12,2),
       (8 + ((n*23)%680) + ((n%5)*0.50))::numeric(12,2),
       5 + (n%26), true, now() - (n||' days')::interval, now()
FROM generate_series(1,120) AS g(n);

-- 40 orders, four lines each. The latter 10 represent mixed outstanding states.
INSERT INTO purchase_orders(order_id,supplier_id,order_date,expected_date,status,notes,created_at,updated_at)
SELECT n, ((n-1)%12)+1, CURRENT_DATE - (n*9), CURRENT_DATE - (n*9) + 14,
       CASE WHEN n<=24 THEN 'received' WHEN n<=30 THEN 'partially_received'
            WHEN n<=35 THEN 'ordered' WHEN n<=38 THEN 'draft' ELSE 'cancelled' END,
       'Fictional seed purchase order '||n, now(), now()
FROM generate_series(1,40) g(n);

INSERT INTO purchase_order_items(order_item_id,order_id,product_id,quantity_ordered,quantity_received,agreed_unit_cost)
SELECT (o.order_id-1)*4+k,
       o.order_id,
       ((o.supplier_id - 1) + ((o.order_id*3 + k*3)%10)*12)+1,
       12 + ((o.order_id+k*3)%35),
       CASE WHEN o.status='received' THEN 12 + ((o.order_id+k*3)%35)
            WHEN o.status='partially_received' THEN (12 + ((o.order_id+k*3)%35))/2
            ELSE 0 END,
       p.unit_cost
FROM purchase_orders o
CROSS JOIN generate_series(1,4) AS k
JOIN products p ON p.product_id=((o.supplier_id - 1) + ((o.order_id*3 + k*3)%10)*12)+1;

-- Seed history independent from opening balances: deterministic audit examples.
INSERT INTO stock_movements(product_id,movement_type,quantity_delta,reference,notes,movement_date,created_at)
SELECT ((n*11-1)%120)+1,
       CASE WHEN n%10=0 THEN 'adjustment' WHEN n%3=0 THEN 'issue' ELSE 'receipt' END,
       CASE WHEN n%10=0 THEN CASE WHEN n%20=0 THEN 3 ELSE -2 END
            WHEN n%3=0 THEN -(1+(n%4)) ELSE 5+(n%8) END,
       'SEED-'||lpad(n::text,4,'0'), 'Fictional historical sample movement',
       CURRENT_DATE - (n%365), now() - (n||' hours')::interval
FROM generate_series(1,480) g(n);

-- Record an opening adjustment so balances reconcile to the signed movement ledger.
WITH movement_totals AS (
    SELECT product_id, SUM(quantity_delta)::integer AS net_change
    FROM stock_movements GROUP BY product_id
)
INSERT INTO stock_movements(product_id,movement_type,quantity_delta,reference,notes,movement_date,created_at)
SELECT p.product_id,'adjustment',
       (CASE WHEN p.product_id%29=0 THEN 0 WHEN p.product_id%13=0 THEN p.reorder_level/2
             ELSE 24 + ((p.product_id*19)%180) END) - COALESCE(m.net_change,0),
       'SEED-OPEN-'||p.product_id,'Fictional opening balance reconciliation',CURRENT_DATE,now()
FROM products p LEFT JOIN movement_totals m USING (product_id)
WHERE (CASE WHEN p.product_id%29=0 THEN 0 WHEN p.product_id%13=0 THEN p.reorder_level/2
            ELSE 24 + ((p.product_id*19)%180) END) - COALESCE(m.net_change,0) <> 0;

INSERT INTO inventory_balances(product_id,quantity_on_hand,last_updated)
SELECT p.product_id,
       CASE WHEN p.product_id%29=0 THEN 0 WHEN p.product_id%13=0 THEN p.reorder_level/2
            ELSE 24 + ((p.product_id*19)%180) END,
       now()
FROM products p;

SELECT setval(pg_get_serial_sequence('categories','category_id'),(SELECT max(category_id) FROM categories));
SELECT setval(pg_get_serial_sequence('suppliers','supplier_id'),(SELECT max(supplier_id) FROM suppliers));
SELECT setval(pg_get_serial_sequence('products','product_id'),(SELECT max(product_id) FROM products));
SELECT setval(pg_get_serial_sequence('purchase_orders','order_id'),(SELECT max(order_id) FROM purchase_orders));
SELECT setval(pg_get_serial_sequence('purchase_order_items','order_item_id'),(SELECT max(order_item_id) FROM purchase_order_items));

COMMIT;
