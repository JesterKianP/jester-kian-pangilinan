CREATE OR REPLACE VIEW v_current_inventory AS
SELECT p.product_id, p.sku, p.product_name, c.category_name, s.supplier_name,
       p.unit_cost, p.unit_price, p.reorder_level, p.active,
       COALESCE(b.quantity_on_hand, 0) AS quantity_on_hand,
       COALESCE(b.quantity_on_hand, 0) * p.unit_cost AS inventory_value_at_cost,
       CASE WHEN COALESCE(b.quantity_on_hand,0) = 0 THEN 'out_of_stock'
            WHEN b.quantity_on_hand <= p.reorder_level THEN 'low_stock'
            ELSE 'healthy' END AS stock_status,
       b.last_updated
FROM products p
JOIN categories c USING (category_id)
JOIN suppliers s USING (supplier_id)
LEFT JOIN inventory_balances b USING (product_id);

CREATE OR REPLACE VIEW v_replenishment AS
SELECT product_id, sku, product_name, category_name, supplier_name,
       quantity_on_hand, reorder_level,
       GREATEST(reorder_level - quantity_on_hand, 0) AS estimated_replenishment_quantity
FROM v_current_inventory
WHERE active AND quantity_on_hand <= reorder_level;

CREATE OR REPLACE VIEW v_inventory_value_by_category AS
SELECT category_name, COUNT(*) FILTER (WHERE active) AS active_product_count,
       COALESCE(SUM(inventory_value_at_cost) FILTER (WHERE active),0)::numeric(14,2) AS inventory_value_at_cost
FROM v_current_inventory
GROUP BY category_name;

CREATE OR REPLACE VIEW v_outstanding_purchase_orders AS
SELECT po.order_id, po.supplier_id, s.supplier_name, po.order_date, po.expected_date, po.status,
       COUNT(poi.order_item_id) AS line_count,
       COALESCE(SUM((poi.quantity_ordered - poi.quantity_received) * poi.agreed_unit_cost),0)::numeric(14,2) AS outstanding_value
FROM purchase_orders po
JOIN suppliers s USING (supplier_id)
LEFT JOIN purchase_order_items poi USING (order_id)
WHERE po.status IN ('ordered','partially_received')
GROUP BY po.order_id, s.supplier_name;
