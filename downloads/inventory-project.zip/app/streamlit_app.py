"""StockWise Inventory Intelligence dashboard entry point."""
from datetime import date, timedelta
from decimal import Decimal
import uuid

import pandas as pd
import plotly.express as px
import streamlit as st
from dotenv import load_dotenv

from app.config import Settings
from app.db import connection
from app import queries
from app.reporting import dataframe_csv, report_frame
from app.services.inventory import apply_movement, create_product, receive_purchase_order, update_product, create_purchase_order
from app.validation import validate_product

load_dotenv()
st.set_page_config(page_title="StockWise Inventory Intelligence", page_icon="📦", layout="wide")
st.markdown("""
<style>
  :root { --sw-ink:#19332e; --sw-muted:#687b75; --sw-line:#e3ebe7; --sw-panel:#ffffff; --sw-accent:#287568; }
  .stApp {background:#f6f8f7; color:var(--sw-ink);}
  .block-container {max-width:1360px; padding-top:2rem; padding-bottom:3rem;}
  section[data-testid="stSidebar"] {background:#fff; border-right:1px solid var(--sw-line); width:260px !important; min-width:260px !important;}
  [data-testid="stSidebar"] h1 {font-size:1.3rem; letter-spacing:-.03em;}
  h1,h2,h3 {color:var(--sw-ink); letter-spacing:-.025em;}
  h1 {font-size:2rem; font-weight:650; margin-bottom:.15rem;}
  h2 {font-size:1.35rem; font-weight:620;}
  h3 {font-size:1.08rem; font-weight:600;}
  .stCaption, [data-testid="stCaptionContainer"], [data-testid="stSidebar"] [data-testid="stCaptionContainer"] {color:var(--sw-muted);}
  [data-testid="stMetric"] {background:var(--sw-panel); border:1px solid var(--sw-line); padding:16px 18px; border-radius:12px; box-shadow:0 1px 2px rgba(25,51,46,.035);}
  [data-testid="stMetricLabel"] p {color:var(--sw-muted); font-size:.82rem;}
  [data-testid="stMetricValue"] {color:var(--sw-ink); font-size:1.55rem; font-weight:650;}
  [data-testid="stDataFrame"] {border:1px solid var(--sw-line); border-radius:10px; overflow:hidden; background:#fff;}
  [data-testid="stPlotlyChart"] {background:#fff; border:1px solid var(--sw-line); border-radius:12px; padding:10px 8px 0;}
  [data-testid="stExpander"] {background:#fff; border:1px solid var(--sw-line); border-radius:10px;}
  [data-testid="stTextInput"] input, [data-testid="stNumberInput"] input, [data-testid="stDateInput"] input {border-radius:8px;}
  .stButton button[kind="primary"], .stFormSubmitButton button[kind="primary"] {background:var(--sw-accent); border-color:var(--sw-accent);}
  hr {border-color:var(--sw-line);}
</style>
""", unsafe_allow_html=True)


def read(sql: str, params=None) -> pd.DataFrame:
    with connection() as conn, conn.cursor() as cur:
        cur.execute(sql, params)
        return pd.DataFrame(cur.fetchall())


def load_page(name: str) -> None:
    st.sidebar.title("StockWise")
    st.sidebar.caption("Inventory Intelligence")
    page = st.sidebar.radio("Workspace", ["Overview", "Product Management", "Stock Control", "Suppliers & Purchasing", "Reports & Exports"], key="page")
    st.sidebar.divider()
    st.sidebar.caption("PostgreSQL is the source of truth. Inventory updates are committed through database functions.")
    try:
        Settings.from_env()
        if page == "Overview": overview()
        elif page == "Product Management": products_page()
        elif page == "Stock Control": stock_page()
        elif page == "Suppliers & Purchasing": purchasing_page()
        else: reports_page()
    except RuntimeError as exc:
        st.error(str(exc))
    except Exception as exc:
        st.error("Could not load this view. Check the database connection and application role grants.")
        st.caption(f"Details: {type(exc).__name__}")


def request_key(name: str) -> str:
    key = f"request_key_{name}"
    if key not in st.session_state: st.session_state[key] = str(uuid.uuid4())
    return st.session_state[key]


def rotate_request_key(name: str) -> None:
    st.session_state[f"request_key_{name}"] = str(uuid.uuid4())


def overview() -> None:
    st.title("Inventory overview")
    st.caption(f"Live snapshot · {date.today():%B %d, %Y}")
    metrics = read(queries.OVERVIEW).iloc[0]
    po_count = read("SELECT COUNT(*) AS open_orders FROM purchase_orders WHERE status IN ('ordered','partially_received')").iloc[0]["open_orders"]
    cols = st.columns(3)
    labels = [("Active products",f"{metrics.active_products:,}"),("Units in stock",f"{metrics.units_in_stock:,}"),("Value at cost",f"${metrics.inventory_value_at_cost:,.2f}"),("Low stock",f"{metrics.low_stock_products:,}"),("Out of stock",f"{metrics.out_of_stock_products:,}"),("Open orders",f"{po_count:,}")]
    for start in range(0, len(labels), 2):
        cols = st.columns(2)
        for col,(label,value) in zip(cols,labels[start:start+2]): col.metric(label,value)
    category=read("SELECT category_name,inventory_value_at_cost FROM v_inventory_value_by_category ORDER BY inventory_value_at_cost DESC")
    status=read("SELECT stock_status,COUNT(*) AS products FROM v_current_inventory WHERE active GROUP BY stock_status ORDER BY stock_status")
    value_tab,status_tab=st.tabs(["Value by category", "Stock status"])
    with value_tab:
        st.subheader("Inventory value by category")
        chart=px.bar(category,x="inventory_value_at_cost",y="category_name",orientation="h",labels={"inventory_value_at_cost":"Value at cost","category_name":"Category"},color_discrete_sequence=["#287568"],template="plotly_white")
        chart.update_layout(height=370,margin=dict(l=10,r=18,t=12,b=36),font=dict(color="#52655f"),showlegend=False)
        st.plotly_chart(chart,width="stretch")
    with status_tab:
        st.subheader("Stock status")
        chart=px.pie(status,names="stock_status",values="products",hole=.66,color="stock_status",color_discrete_map={"healthy":"#287568","low_stock":"#d39432","out_of_stock":"#bb5b5b"},template="plotly_white")
        chart.update_layout(height=370,margin=dict(l=12,r=12,t=12,b=12),font=dict(color="#52655f"))
        st.plotly_chart(chart,width="stretch")
    st.subheader("Products needing attention")
    attention=read("SELECT sku,product_name,quantity_on_hand,stock_status FROM v_current_inventory WHERE active AND stock_status<>'healthy' ORDER BY CASE stock_status WHEN 'out_of_stock' THEN 0 WHEN 'low_stock' THEN 1 ELSE 2 END, product_name")
    attention=attention.rename(columns={"sku":"SKU","product_name":"Product","quantity_on_hand":"On hand","stock_status":"Status"})
    attention["Status"]=attention["Status"].map({"healthy":"Healthy","low_stock":"Low stock","out_of_stock":"Out of stock"})
    st.dataframe(attention,width="stretch",hide_index=True)


def products_page() -> None:
    st.title("Product catalog")
    st.caption("Search and maintain your active inventory items.")
    filters=read("SELECT category_id,category_name FROM categories ORDER BY category_name")
    suppliers=read("SELECT supplier_id,supplier_name FROM suppliers WHERE active ORDER BY supplier_name")
    with st.container(border=True):
        c1,c2,c3=st.columns([1.5,1.25,1.25])
        search=c1.text_input("Search",placeholder="SKU or product name")
        category=c2.selectbox("Category",[None,*filters.category_id.tolist()],format_func=lambda x:"All categories" if x is None else filters.set_index("category_id").loc[x,"category_name"])
        supplier=c3.selectbox("Supplier",[None,*suppliers.supplier_id.tolist()],format_func=lambda x:"All suppliers" if x is None else suppliers.set_index("supplier_id").loc[x,"supplier_name"])
        c4,c5=st.columns(2)
        active=c4.selectbox("Product status",[True,False,None],format_func=lambda x:"Active" if x is True else "Inactive" if x is False else "All")
        sort_label=c5.selectbox("Sort by",["Product name","Inventory value","Quantity on hand","Stock status"])
    order_by={"Product name":"vi.product_name","Inventory value":"vi.inventory_value_at_cost DESC","Quantity on hand":"vi.quantity_on_hand","Stock status":"CASE vi.stock_status WHEN 'out_of_stock' THEN 0 WHEN 'low_stock' THEN 1 ELSE 2 END,vi.product_name"}[sort_label]
    frame=read(f"SELECT vi.product_id,vi.sku,vi.product_name,vi.quantity_on_hand,vi.stock_status FROM v_current_inventory vi JOIN products p USING(product_id) WHERE (%s::text IS NULL OR vi.sku ILIKE %s OR vi.product_name ILIKE %s) AND (%s::integer IS NULL OR p.category_id=%s) AND (%s::integer IS NULL OR p.supplier_id=%s) AND (%s::boolean IS NULL OR vi.active=%s) ORDER BY {order_by}",(f"%{search}%" if search else None,f"%{search}%" if search else None,f"%{search}%" if search else None,category,category,supplier,supplier,active,active))
    st.caption(f"{len(frame):,} products")
    display=frame.drop(columns=["product_id"]).rename(columns={"sku":"SKU","product_name":"Product","quantity_on_hand":"On hand","stock_status":"Status"})
    display["Status"]=display["Status"].map({"healthy":"Healthy","low_stock":"Low stock","out_of_stock":"Out of stock"})
    st.dataframe(display,width="stretch",hide_index=True)
    with st.expander("Add product"):
        with st.form("add_product"):
            sku=st.text_input("SKU"); name=st.text_input("Product name")
            cats=st.selectbox("Category",filters.category_id.tolist(),format_func=lambda x:filters.set_index("category_id").loc[x,"category_name"])
            supp=st.selectbox("Default supplier",suppliers.supplier_id.tolist(),format_func=lambda x:suppliers.set_index("supplier_id").loc[x,"supplier_name"])
            cost=st.number_input("Unit cost",min_value=0.0,step=.01); price=st.number_input("Unit price",min_value=0.0,step=.01); reorder=st.number_input("Reorder level",min_value=0,step=1)
            submitted=st.form_submit_button("Create product",type="primary")
        if submitted:
            errors=validate_product(sku=sku,product_name=name,unit_cost=cost,unit_price=price,reorder_level=reorder)
            if errors: st.error(" ".join(errors))
            else:
                try: create_product(sku=sku.strip(),product_name=name.strip(),category_id=cats,supplier_id=supp,unit_cost=Decimal(str(cost)),unit_price=Decimal(str(price)),reorder_level=reorder); st.success("Product created."); st.rerun()
                except Exception as exc: st.error("Product could not be created. Verify SKU uniqueness and selected records."); st.caption(type(exc).__name__)
    with st.expander("Edit product or change activation"):
        ids=frame.product_id.tolist() if not frame.empty else []
        if ids:
            selected=st.selectbox("Product",ids,format_func=lambda x:frame.set_index("product_id").loc[x,"sku"])
            row=read("SELECT * FROM products WHERE product_id=%s",(selected,)).iloc[0]
            edit_suppliers=read("SELECT supplier_id,supplier_name FROM suppliers ORDER BY supplier_name")
            with st.form("edit_product"):
                edit_sku=st.text_input("SKU",row.sku); edit_name=st.text_input("Product name",row.product_name)
                edit_category=st.selectbox("Category",filters.category_id.tolist(),index=filters.category_id.tolist().index(row.category_id))
                edit_supplier=st.selectbox("Default supplier",edit_suppliers.supplier_id.tolist(),index=edit_suppliers.supplier_id.tolist().index(row.supplier_id),format_func=lambda x:edit_suppliers.set_index("supplier_id").loc[x,"supplier_name"])
                edit_cost=st.number_input("Cost",min_value=0.0,value=float(row.unit_cost)); edit_price=st.number_input("Price",min_value=0.0,value=float(row.unit_price)); edit_reorder=st.number_input("Reorder level",min_value=0,value=int(row.reorder_level)); edit_active=st.checkbox("Active",value=bool(row.active)); save=st.form_submit_button("Save changes")
            if save:
                errors=validate_product(sku=edit_sku,product_name=edit_name,unit_cost=edit_cost,unit_price=edit_price,reorder_level=int(edit_reorder))
                if errors: st.error(" ".join(errors))
                else:
                    try:
                        update_product(product_id=selected,sku=edit_sku.strip(),product_name=edit_name.strip(),category_id=edit_category,supplier_id=edit_supplier,unit_cost=Decimal(str(edit_cost)),unit_price=Decimal(str(edit_price)),reorder_level=int(edit_reorder),active=edit_active)
                        st.success("Product updated."); st.rerun()
                    except Exception as exc: st.error("Product could not be updated. Verify SKU uniqueness and selected records."); st.caption(type(exc).__name__)


def stock_page() -> None:
    st.title("Stock control")
    st.caption("Review balances and record auditable stock changes.")
    t_current,t_low,t_out=st.tabs(["Current stock","Low stock","Out of stock"])
    with t_current:
        current=read("SELECT sku,product_name,quantity_on_hand,reorder_level FROM v_current_inventory WHERE active ORDER BY product_name")
        current=current.rename(columns={"sku":"SKU","product_name":"Product","quantity_on_hand":"On hand","reorder_level":"Reorder at"})
        st.dataframe(current,width="stretch",hide_index=True)
    with t_low:
        low=read("SELECT sku,product_name,quantity_on_hand,reorder_level FROM v_current_inventory WHERE active AND stock_status='low_stock' ORDER BY quantity_on_hand,product_name")
        low=low.rename(columns={"sku":"SKU","product_name":"Product","quantity_on_hand":"On hand","reorder_level":"Reorder at"})
        st.dataframe(low,width="stretch",hide_index=True)
    with t_out:
        out=read("SELECT sku,product_name,quantity_on_hand,reorder_level FROM v_current_inventory WHERE active AND stock_status='out_of_stock' ORDER BY product_name")
        out=out.rename(columns={"sku":"SKU","product_name":"Product","quantity_on_hand":"On hand","reorder_level":"Reorder at"})
        st.dataframe(out,width="stretch",hide_index=True)
    products=read("SELECT product_id,sku,product_name FROM products WHERE active ORDER BY product_name")
    if products.empty: st.info("No active products found."); return
    product=st.selectbox("Product",products.product_id.tolist(),format_func=lambda x:products.set_index("product_id").loc[x,"sku"]+" · "+products.set_index("product_id").loc[x,"product_name"])
    t1,t2,t3=st.tabs(["Receive stock","Issue stock","Authorized adjustment"])
    with t1:
        with st.form("manual_receipt"):
            q=st.number_input("Quantity received",min_value=1,step=1); ref=st.text_input("Reference (optional)"); submit=st.form_submit_button("Record receipt")
        if submit:
            try: apply_movement(product_id=product,movement_type="receipt",quantity_delta=int(q),reference=ref or None,request_key=request_key("manual_receipt")); rotate_request_key("manual_receipt"); st.success("Receipt recorded."); st.rerun()
            except Exception as exc: st.error("Receipt failed; no stock was changed."); st.caption(type(exc).__name__)
    with t2:
        with st.form("issue"):
            q=st.number_input("Quantity issued",min_value=1,step=1,key="issue_q"); ref=st.text_input("Reference (optional)",key="issue_ref"); submit=st.form_submit_button("Record issue")
        if submit:
            try: apply_movement(product_id=product,movement_type="issue",quantity_delta=-int(q),reference=ref or None,request_key=request_key("issue")); rotate_request_key("issue"); st.success("Issue recorded."); st.rerun()
            except Exception as exc: st.error("Issue failed; check available stock."); st.caption(type(exc).__name__)
    with t3:
        with st.form("adjustment"):
            delta=st.number_input("Signed quantity change",step=1); ref=st.text_input("Reason or reference (required)",key="adjust_ref"); notes=st.text_area("Notes"); submit=st.form_submit_button("Record adjustment")
        if submit:
            if not ref.strip() and not notes.strip(): st.error("Enter a reason or reference.")
            elif delta==0: st.error("Adjustment must change quantity.")
            else:
                try: apply_movement(product_id=product,movement_type="adjustment",quantity_delta=int(delta),reference=ref or None,notes=notes or None,request_key=request_key("adjustment")); rotate_request_key("adjustment"); st.success("Adjustment recorded."); st.rerun()
                except Exception as exc: st.error("Adjustment failed; no stock was changed."); st.caption(type(exc).__name__)
    st.subheader("Movement history")
    history=read("SELECT movement_type,quantity_delta,reference,movement_date FROM stock_movements WHERE product_id=%s ORDER BY movement_date DESC,movement_id DESC LIMIT 100",(product,))
    history=history.rename(columns={"movement_type":"Type","quantity_delta":"Change","reference":"Reference","movement_date":"Date"})
    st.dataframe(history,width="stretch",hide_index=True)


def purchasing_page() -> None:
    st.title("Suppliers & purchasing")
    st.caption("Manage supplier contacts and follow purchase orders through receipt.")
    search=st.text_input("Search suppliers")
    directory=read("SELECT supplier_name,contact_name,contact_email,phone,active FROM suppliers WHERE supplier_name ILIKE %s ORDER BY supplier_name",(f"%{search}%",))
    directory=directory.rename(columns={"supplier_name":"Supplier","contact_name":"Contact","contact_email":"Email","phone":"Phone","active":"Active"})
    st.dataframe(directory,width="stretch",hide_index=True)
    with st.expander("Create purchase order"):
        supplier_options=read("SELECT supplier_id,supplier_name FROM suppliers WHERE active ORDER BY supplier_name")
        if not supplier_options.empty:
            supplier_id=st.selectbox("Supplier",supplier_options.supplier_id.tolist(),format_func=lambda x:supplier_options.set_index("supplier_id").loc[x,"supplier_name"],key="po_supplier")
            product_options=read("SELECT product_id,sku,product_name,unit_cost FROM products WHERE active AND supplier_id=%s ORDER BY product_name",(supplier_id,))
            chosen=st.multiselect("Products",product_options.product_id.tolist(),format_func=lambda x:product_options.set_index("product_id").loc[x,"sku"]+" · "+product_options.set_index("product_id").loc[x,"product_name"],key="po_products")
            with st.form("create_po"):
                lines=[]
                for pid in chosen:
                    p=product_options.set_index("product_id").loc[pid]
                    qty=st.number_input(f"Quantity · {p.sku}",min_value=1,value=10,key=f"po_qty_{pid}")
                    cost=st.number_input(f"Agreed cost · {p.sku}",min_value=0.0,value=float(p.unit_cost),step=.01,key=f"po_cost_{pid}")
                    lines.append({"product_id":int(pid),"quantity_ordered":int(qty),"agreed_unit_cost":str(Decimal(str(cost)))})
                expected=st.date_input("Expected delivery",value=date.today()+timedelta(days=14)); notes=st.text_area("Notes"); create=st.form_submit_button("Create order",type="primary")
            if create:
                if not lines: st.error("Select at least one product.")
                else:
                    try: order_id=create_purchase_order(supplier_id=supplier_id,expected_date=expected,notes=notes or None,items=lines); st.success(f"Purchase order {order_id} created."); st.rerun()
                    except Exception as exc: st.error("Purchase order could not be created."); st.caption(type(exc).__name__)
    orders=read("SELECT po.order_id,s.supplier_name,po.expected_date,po.status FROM purchase_orders po JOIN suppliers s USING(supplier_id) ORDER BY po.expected_date DESC")
    orders=orders.rename(columns={"order_id":"Order","supplier_name":"Supplier","expected_date":"Expected","status":"Status"})
    st.subheader("Purchase orders")
    st.dataframe(orders,width="stretch",hide_index=True)
    order_ids=orders.Order.tolist()
    if order_ids:
        order=st.selectbox("Order details",order_ids)
        lines=read("SELECT i.order_item_id,p.sku,p.product_name,i.quantity_ordered,i.quantity_received,i.agreed_unit_cost FROM purchase_order_items i JOIN products p USING(product_id) WHERE order_id=%s ORDER BY p.product_name",(order,))
        display_lines=lines.drop(columns=["order_item_id"]).rename(columns={"sku":"SKU","product_name":"Product","quantity_ordered":"Ordered","quantity_received":"Received","agreed_unit_cost":"Unit cost"})
        st.dataframe(display_lines,width="stretch",hide_index=True)
        open_lines=lines[lines.quantity_received < lines.quantity_ordered]
        if not open_lines.empty and read("SELECT status FROM purchase_orders WHERE order_id=%s",(order,)).iloc[0].status in ("ordered","partially_received"):
            with st.form("po_receive"):
                selected=st.selectbox("Line to receive",open_lines.order_item_id.tolist(),format_func=lambda x:open_lines.set_index("order_item_id").loc[x,"sku"])
                remaining=int(open_lines.set_index("order_item_id").loc[selected,"quantity_ordered"]-open_lines.set_index("order_item_id").loc[selected,"quantity_received"])
                qty=st.number_input("Receive quantity",min_value=1,max_value=remaining,step=1); reference=st.text_input("Delivery reference"); submit=st.form_submit_button("Receive against order")
            if submit:
                try: result=receive_purchase_order(order_id=order,receipts=[{"order_item_id":selected,"quantity":int(qty)}],reference=reference or None,request_key=request_key(f"po_{order}_{selected}")); rotate_request_key(f"po_{order}_{selected}"); st.success(f"Receipt saved. Order status: {result['status']}."); st.rerun()
                except Exception as exc: st.error("Purchase order receipt failed; transaction was rolled back."); st.caption(type(exc).__name__)


def reports_page() -> None:
    st.title("Reports & exports")
    name=st.selectbox("Report",list(("Inventory valuation","Replenishment estimate","Supplier purchasing","Stock movements")))
    if name=="Replenishment estimate":
        st.caption("Suggested quantities use configured reorder thresholds; they are not demand forecasts.")
    start,end=st.date_input("Date range (used for movement and purchasing reports)",(date.today()-timedelta(days=365),date.today()))
    frame=report_frame(name,start,end)
    frame=frame.rename(columns={column:column.replace("_"," ").title().replace("Sku","SKU").replace("Id","ID") for column in frame.columns})
    st.caption(f"{len(frame):,} rows")
    if frame.empty: st.info("No rows match these filters.")
    else: st.dataframe(frame,width="stretch",hide_index=True)
    st.download_button("Download filtered CSV",data=dataframe_csv(frame),file_name=name.lower().replace(" ","_")+".csv",mime="text/csv",disabled=frame.empty)


if __name__ == "__main__":
    load_page("StockWise")

