"""Fast form validation; database constraints remain authoritative."""
from decimal import Decimal, InvalidOperation


def validate_product(*, sku: str, product_name: str, unit_cost: object,
                     unit_price: object, reorder_level: object) -> list[str]:
    errors: list[str] = []
    if not sku.strip(): errors.append("SKU is required.")
    if not product_name.strip(): errors.append("Product name is required.")
    for label, value in (("Unit cost", unit_cost), ("Unit price", unit_price)):
        try:
            amount = Decimal(str(value))
            if not amount.is_finite() or amount < 0: errors.append(f"{label} must be a nonnegative amount.")
        except (InvalidOperation, ValueError):
            errors.append(f"{label} must be a valid amount.")
    if not isinstance(reorder_level, int) or reorder_level < 0:
        errors.append("Reorder level must be a nonnegative whole number.")
    return errors
