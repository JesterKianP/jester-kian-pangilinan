"""Parameterized PostgreSQL read queries used by application and reports."""

OVERVIEW = """
SELECT COUNT(*) FILTER (WHERE active) AS active_products,
       COALESCE(SUM(quantity_on_hand),0) AS units_in_stock,
       COALESCE(SUM(inventory_value_at_cost) FILTER (WHERE active),0)::numeric(14,2) AS inventory_value_at_cost,
       COUNT(*) FILTER (WHERE active AND stock_status='low_stock') AS low_stock_products,
       COUNT(*) FILTER (WHERE active AND stock_status='out_of_stock') AS out_of_stock_products
FROM v_current_inventory
"""

INVENTORY_FILTERED = """
SELECT vi.* FROM v_current_inventory vi
JOIN products p USING (product_id)
WHERE (%s::integer IS NULL OR p.category_id = %s)
  AND (%s::integer IS NULL OR p.supplier_id = %s)
  AND (%s::boolean IS NULL OR vi.active = %s)
ORDER BY vi.product_name
"""

MOVEMENT_HISTORY = """
SELECT movement_id,movement_type,quantity_delta,reference,notes,movement_date,created_at
FROM stock_movements WHERE product_id=%s
ORDER BY movement_date DESC,movement_id DESC LIMIT %s
"""

CREATE_PRODUCT = """
SELECT stockwise_create_product(%s,%s,%s,%s,%s,%s,%s) AS product_id
"""
UPDATE_PRODUCT = "SELECT stockwise_update_product(%s,%s,%s,%s,%s,%s,%s,%s,%s)"
CREATE_PURCHASE_ORDER = "SELECT stockwise_create_purchase_order(%s,%s,%s,%s::jsonb) AS order_id"

APPLY_MOVEMENT = """
SELECT * FROM stockwise_apply_movement(%s,%s,%s,%s::uuid,%s,%s,%s)
"""

RECEIVE_PURCHASE_ORDER = """
SELECT * FROM stockwise_receive_purchase_order(%s,%s::jsonb,%s::uuid,%s,%s)
"""
