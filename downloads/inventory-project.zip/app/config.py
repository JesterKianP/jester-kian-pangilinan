"""Runtime configuration loaded from environment, with no credential defaults."""
from dataclasses import dataclass
import os


@dataclass(frozen=True)
class Settings:
    database_url: str

    @classmethod
    def from_env(cls) -> "Settings":
        value = os.getenv("DATABASE_URL", "").strip()
        if not value:
            raise RuntimeError("DATABASE_URL is required. Copy .env.example to .env and configure PostgreSQL.")
        if not value.startswith(("postgresql://", "postgres://")):
            raise RuntimeError("DATABASE_URL must use PostgreSQL.")
        return cls(database_url=value)
