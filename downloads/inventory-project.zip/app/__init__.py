"""StockWise application package."""
