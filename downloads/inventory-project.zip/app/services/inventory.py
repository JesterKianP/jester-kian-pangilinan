"""Inventory services. Database functions remain the authoritative write logic."""
import json
import uuid
from datetime import date
from decimal import Decimal

from app.db import connection
from app.queries import APPLY_MOVEMENT, CREATE_PRODUCT, RECEIVE_PURCHASE_ORDER, UPDATE_PRODUCT, CREATE_PURCHASE_ORDER


def create_product(*, sku: str, product_name: str, category_id: int, supplier_id: int,
                   unit_cost: Decimal, unit_price: Decimal, reorder_level: int) -> int:
    with connection() as conn, conn.cursor() as cur:
        cur.execute(CREATE_PRODUCT, (sku, product_name, category_id, supplier_id, unit_cost, unit_price, reorder_level))
        return cur.fetchone()["product_id"]


def apply_movement(*, product_id: int, movement_type: str, quantity_delta: int,
                   reference: str | None = None, notes: str | None = None,
                   movement_date: date | None = None, request_key: uuid.UUID | str | None = None) -> dict:
    with connection() as conn, conn.cursor() as cur:
        cur.execute(APPLY_MOVEMENT, (product_id, movement_type, quantity_delta, str(request_key or uuid.uuid4()), reference, notes, movement_date))
        return cur.fetchone()


def receive_purchase_order(*, order_id: int, receipts: list[dict[str, int]],
                           reference: str | None = None, received_date: date | None = None,
                           request_key: uuid.UUID | str | None = None) -> dict:
    if not receipts:
        raise ValueError("Provide at least one order line to receive.")
    if any(set(line) != {"order_item_id", "quantity"} for line in receipts):
        raise ValueError("Each receipt line must contain order_item_id and quantity.")
    if any(not isinstance(line["quantity"], int) or line["quantity"] <= 0 for line in receipts):
        raise ValueError("Receipt quantities must be positive whole numbers.")
    payload = json.dumps(receipts)
    with connection() as conn, conn.cursor() as cur:
        cur.execute(RECEIVE_PURCHASE_ORDER, (order_id, payload, str(request_key or uuid.uuid4()), reference, received_date))
        return cur.fetchone()


def update_product(*, product_id: int, sku: str, product_name: str, category_id: int, supplier_id: int, unit_cost: Decimal,
                   unit_price: Decimal, reorder_level: int, active: bool) -> None:
    with connection() as conn, conn.cursor() as cur:
        cur.execute(UPDATE_PRODUCT, (product_id, sku, product_name, category_id, supplier_id, unit_cost, unit_price, reorder_level, active))


def create_purchase_order(*, supplier_id: int, expected_date: date | None, notes: str | None,
                          items: list[dict]) -> int:
    if not items: raise ValueError("A purchase order needs at least one item.")
    payload = json.dumps(items, default=str)
    with connection() as conn, conn.cursor() as cur:
        cur.execute(CREATE_PURCHASE_ORDER, (supplier_id, expected_date, notes, payload))
        return cur.fetchone()["order_id"]
