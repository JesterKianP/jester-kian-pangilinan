"""Reporting data access and safe CSV serialization."""
from datetime import date

import pandas as pd

from app.db import fetch_all

REPORT_SQL = {
    "Inventory valuation": "SELECT sku,product_name,category_name,supplier_name,quantity_on_hand,unit_cost,inventory_value_at_cost FROM v_current_inventory WHERE active ORDER BY inventory_value_at_cost DESC",
    "Replenishment estimate": "SELECT sku,product_name,category_name,supplier_name,quantity_on_hand,reorder_level,estimated_replenishment_quantity FROM v_replenishment ORDER BY quantity_on_hand,product_name",
    "Supplier purchasing": "SELECT s.supplier_name,COUNT(DISTINCT po.order_id) AS order_count,SUM(i.quantity_received) AS units_received,SUM(i.quantity_received*i.agreed_unit_cost)::numeric(14,2) AS received_cost FROM suppliers s JOIN purchase_orders po USING(supplier_id) JOIN purchase_order_items i USING(order_id) WHERE po.order_date BETWEEN %s AND %s AND po.status <> 'cancelled' GROUP BY s.supplier_name ORDER BY received_cost DESC NULLS LAST",
    "Stock movements": "SELECT m.movement_date,p.sku,p.product_name,m.movement_type,m.quantity_delta,m.reference,m.notes FROM stock_movements m JOIN products p USING(product_id) WHERE m.movement_date BETWEEN %s AND %s ORDER BY m.movement_date DESC,m.movement_id DESC",
}


def report_frame(name: str, start: date | None = None, end: date | None = None) -> pd.DataFrame:
    if name not in REPORT_SQL:
        raise ValueError("Unknown report.")
    params = (start, end) if name in {"Supplier purchasing", "Stock movements"} else None
    return pd.DataFrame(fetch_all(REPORT_SQL[name], params))


def dataframe_csv(frame: pd.DataFrame) -> bytes:
    """Serialize the exact filtered frame; empty frames still yield valid headers."""
    return frame.to_csv(index=False, lineterminator="\n").encode("utf-8-sig")
